import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;


public class Gmaillogin {
	
	@Test
	
	
	
	public void myfirstgmail(){
		 //initializing chrome driver
		
		
		System.setProperty("webdriver.chrome.driver", "C:/drivers/chromedriver_win32/chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		
		//open gmail
		
		driver.get("http://www.gmail.com");
		driver.manage().window().maximize();
		//enter user ID
		WebElement element=driver.findElement(By.id("Email"));
		element.sendKeys("devsara2016@gmail.com");
		// wait 5 seconds to enter user id
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		//click on Next button
		driver.findElement(By.xpath("//div/input[@class='rc-button rc-button-submit']")).click();
		//enter password
		WebElement elementpass=driver.findElement(By.id("Passwd"));
		elementpass.sendKeys("1qaz2wsx!");
		//wait 10 seconds to enter password
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//submit button
		driver.findElement(By.xpath("//input[@id='signIn']")).click();
		//wait 10 seconds to load the gmail
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//compose a mail
		driver.findElement(By.xpath("//div[@class='z0']/div")).click();
		driver.findElement(By.className("vO")).sendKeys("devsara2016@gmail.com");
		driver.findElement(By.className("aoT")).sendKeys("Testing Selenium");
		driver.findElement(By.xpath("//div[@class='Am Al editable LW-avf']")).sendKeys("This is a test mail.Please ignore");
		
		//wait 10 seconds to load the gmail
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//click send button
		driver.findElement(By.xpath("//div[text()='Send']")).click();
		
		//click on inbox
		driver.findElement(By.xpath("//a[@title='Inbox (1)']")).click();
		
		
		
		
		
		
		
	}
}
